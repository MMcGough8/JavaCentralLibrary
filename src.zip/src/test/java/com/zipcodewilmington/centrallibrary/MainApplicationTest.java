package com.zipcodewilmington.centrallibrary;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

/**
 * Created by n3pjk on 6/9/2025.
 */
public class MainApplicationTest {

    @Test
    public void shouldAnswerWithTrue() {
        Assertions.assertTrue(true);
    }

}
